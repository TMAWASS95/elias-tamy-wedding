export const wedding = {
  couple: "Tamy & John",
  tagline: "We’re getting married",
  date: "2026-09-12T18:00:00",
  venue: {
    name: "Byblos Beach Resort",
    address: "Byblos, Lebanon",
    map: "https://maps.google.com"
  }
};
