import Cover from "./components/Cover";
import Story from "./components/Story";
import Countdown from "./components/Countdown";
import EventDetails from "./components/EventDetails";
import RSVP from "./components/RSVP";

export default function App() {
  return (
    <>
      <Cover />
      <Story />
      <Countdown />
      <EventDetails />
      <RSVP />
    </>
  );
}
