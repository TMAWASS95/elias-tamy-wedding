import { motion } from "framer-motion";
import { wedding } from "../data";

export default function Cover() {
  return (
    <div className="cover">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <div className="names">{wedding.couple}</div>
        <p>{wedding.tagline}</p>
        <p>{new Date(wedding.date).toDateString()}</p>
      </motion.div>

      <motion.div
        className="scroll"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
      >
        Scroll ↓
      </motion.div>
    </div>
  );
}
